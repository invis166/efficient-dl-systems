mkdir data/
wget https://s3.amazonaws.com/research.metamind.io/wikitext/wikitext-103-raw-v1.zip -O data/wikitext.zip
unzip data/wikitext.zip -d data/
