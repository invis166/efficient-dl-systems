# Download and unpack data
wget https://www.dropbox.com/s/tc1qo73rrm3gt3m/CARVANA.zip
unzip -q CARVANA.zip
rm -rf ./train/.DS_Store ./train_masks/.DS_Store CARVANA.zip
